#include <iostream>
#include <chrono>
#include <ctime>
#include <cmath>

#include <set>
#include <map>
#include <unordered_map>

#include "Vec2.hpp"
#include "Figure.hpp"
#include "Matlab_file.hpp"
#include "Methode.hpp"

int main(){
	unsigned int start = 10;
	unsigned int N = 13;

	std::set<int> se;
	std::multiset<int> ms;
	std::map<int, int> ma;
	std::unordered_map<int, int> un;

	Figure figure1;
	Figure figure2;
	Figure figure3;
	Figure figure4;

	figure4.title = "comparaison clear";
	figure4.legends = "'set', 'multiset', 'map', 'unordered map'";

	Matlab_file matlab_file;

	for(unsigned int i = start; i < start + N; ++i){
		std::cout<<"i : "<< i<< "\t| 2^i (nbr of elements added): "<< pow(2, i)<< std::endl;
		figure1.points.push_back(test::clear(se, i));
		figure2.points.push_back(test::clear(ms, i));
		figure3.points.push_back(test::clear(ma, i));
		figure4.points.push_back(test::clear(un, i));
	}
	matlab_file.hold_on();

	matlab_file += figure1;
	matlab_file += figure2;
	matlab_file += figure3;
	matlab_file += figure4;

	matlab_file.create_file();
	return 0;
}