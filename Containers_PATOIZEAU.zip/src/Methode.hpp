#ifndef METHODE_HPP
#define METHODE_HPP

#include <chrono>
#include <ctime>
#include <cmath>

#include <map>
#include <unordered_map>

#include "Vec2.hpp"

namespace test{

	// Pour set et multiset d'un coup
	template<template<class, class, class> class TContainer, typename TObject>
	Vec2 emplace(TContainer<TObject, std::less<TObject>, std::allocator<TObject>> &container, unsigned long int n){
		container.clear();
		std::chrono::time_point<std::chrono::system_clock> start, end;

		TObject o = TObject();
		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			o *= 2;
			container.emplace(o);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<template<class, class, class> class TContainer, typename TObject>
	Vec2 erase(TContainer<TObject, std::less<TObject>, std::allocator<TObject>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		for(int i = 0; i < pow(2, n); ++i){
			o *= 2;
			container.emplace(o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;
		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			o /= 2;
			container.erase(o);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<template<class, class, class> class TContainer, typename TObject>
	Vec2 clear(TContainer<TObject, std::less<TObject>, std::allocator<TObject>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		for(int i = 0; i < pow(2, n); ++i){
			o *= 2;
			container.emplace(o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;
		start = std::chrono::system_clock::now();
		container.clear();
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<template<class, class, class> class TContainer, typename TObject>
	Vec2 equal(TContainer<TObject, std::less<TObject>, std::allocator<TObject>> &container, unsigned long int n){
		TContainer<TObject, std::less<TObject>, std::allocator<TObject>> c = TContainer<TObject, std::less<TObject>, std::allocator<TObject>>();
		container.clear();

		TObject o = TObject();
		for(int i = 0; i < pow(2, n); ++i){
			o *= 2;
			container.emplace(o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;
		start = std::chrono::system_clock::now();
		c = container;
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	// Seulement pour map
	template<typename TKey, typename TObject>
	Vec2 emplace(std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();
		std::chrono::time_point<std::chrono::system_clock> start, end;

		TObject o = TObject();
		TKey k = TKey();

		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 erase(std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			k /= 2;
			o /= 2;
			container.erase(k);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 clear(std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		container.clear();
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 equal(std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>> &container, unsigned long int n){
		std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>> c = std::map<TKey, TObject, std::less<TKey>, std::allocator<std::pair<const TKey, TObject>>>();
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		c = container;
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	// Seulement pour unordered_map
	template<typename TKey, typename TObject>
	Vec2 emplace(std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();
		std::chrono::time_point<std::chrono::system_clock> start, end;

		TObject o = TObject();
		TKey k = TKey();

		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 erase(std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		for(int i = 0; i < pow(2, n); ++i){
			k /= 2;
			o /= 2;
			container.erase(k);
		}
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 clear(std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>> &container, unsigned long int n){
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		container.clear();
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}

	template<typename TKey, typename TObject>
	Vec2 equal(std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>> &container, unsigned long int n){
		std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>> c = std::unordered_map<TKey, TObject, std::hash<TKey>, std::equal_to<TKey>, std::allocator< std::pair<const TKey, TObject>>>();
		container.clear();

		TObject o = TObject();
		TKey k = TKey();

		for(int i = 0; i < pow(2, n); ++i){
			k *= 2;
			o *= 2;
			container.emplace(k, o);
		}

		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();
		c = container;
		end = std::chrono::system_clock::now();

		int elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
		double resultat = (double)(elapsed / pow(2, n) * pow(10, 6));

		return Vec2(pow(2, n), resultat);
	}
}

#endif