#ifndef FIGURE_HPP
#define FIGURE_HPP
#include <vector>
#include <string>

#include "Vec2.hpp"

class Figure
{
    public:
        Figure();
        virtual ~Figure();

        std::string get_code(bool hold_on) const;

        std::vector<Vec2> points;

        int figure_number;
        int data_number;
        std::string options;
        std::string title;
        std::string legends;

    private:
};

#endif // FIGURE_HPP
