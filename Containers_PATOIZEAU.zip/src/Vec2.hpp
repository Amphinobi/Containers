#ifndef VEC2_HPP
#define VEC2_HPP
#include <ostream>

class Vec2
{
    public:
        Vec2() = default;
        Vec2(double, double);
        virtual ~Vec2();

        double x;
        double y;

    protected:

    private:
};

std::ostream& operator<<(std::ostream &os, Vec2 const& v);

#endif // VEC2_HPP
