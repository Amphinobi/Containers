#ifndef MATLAB_FILE_HPP
#define MATLAB_FILE_HPP
#include <string>
#include <vector>

#include "Figure.hpp"

class Matlab_file
{
    public:
        Matlab_file();
        Matlab_file(std::string const&);
        virtual ~Matlab_file();

        void create_file() const;
        void hold_on();
        void hold_off();

        Matlab_file& operator+=(Figure& f);

    protected:
        std::string filename;
        std::vector<Figure*> figures;

        bool hold;

    private:
};

#endif // MATLAB_FILE_HPP
