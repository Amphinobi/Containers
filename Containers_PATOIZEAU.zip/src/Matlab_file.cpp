#include "Matlab_file.hpp"

#include <fstream>
#include <iostream>

Matlab_file::Matlab_file()
{
    filename = "defaultFilename.m";
    hold = false;
}

Matlab_file::Matlab_file(std::string const& s) : filename(s){

}

Matlab_file::~Matlab_file()
{
    //dtor
}

void Matlab_file::create_file() const{
    std::ofstream file(filename);

    file<< "clc; clear all; close all;"<< std::endl<< std::endl;

    bool holded = false;
    if(figures.size() != 0){
        for(unsigned int i = 0; i < figures.size(); ++i){
            if((i >= 1) && (figures[i - 1]->figure_number == figures[i]->figure_number))
                holded = true;
            else
                holded = false;
            file<< figures[i]->get_code(holded);
        }
    }

    file.close();
}

void Matlab_file::hold_on(){
    hold = true;
}

void Matlab_file::hold_off(){
    hold = false;
}

Matlab_file& Matlab_file::operator+=(Figure& f){
    f.data_number = figures.size() + 1;

    if((!hold) || (figures.size() == 0))
        f.figure_number = figures.size() + 1;
    else
        f.figure_number = figures[figures.size() - 1]->figure_number;

    figures.push_back(&f);

    return *this;
}
