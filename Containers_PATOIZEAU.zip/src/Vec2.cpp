#include "Vec2.hpp"

Vec2::Vec2(double _x, double _y): x(_x), y(_y)
{

}

Vec2::~Vec2()
{
    //dtor
}

std::ostream& operator<<(std::ostream &os, Vec2 const& v){
    os<< "Vec: "<< v.x<< "\t,"<< v.y<< std::endl;
    return os;
}
