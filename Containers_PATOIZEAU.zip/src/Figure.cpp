#include "Figure.hpp"
#include <fstream>
#include <string>
#include <sstream>

Figure::Figure(){
    figure_number = 1;
    data_number = 1;
    options = "";
    title = "default_title n�1";
    legends = "";
}

Figure::~Figure()
{
    //dtor
}

std::string Figure::get_code(bool hold_on) const{
    /// DATA EDITING
    std::string Data_filename = "DATA" + std::to_string(data_number) + ".txt";
    std::ofstream file(Data_filename);

    for(unsigned int i = 0; i < points.size(); ++i){
        file<< points[i].x<< "\t"<< points[i].y<< std::endl;
    }

    file.close();

    /// .m EDITING
    std::stringstream sstream;

    // Editing section
   // sstream<< std::endl<< "%% SECTION : figure "<< figure_number<< std::endl<< std::endl;

    // Importing data
    sstream<< std::endl<< "DATA"<< data_number<< " = importdata('"<< Data_filename<< "', '\\t');"<< std::endl<< std::endl;

    // Selecting figure
    sstream<< "figure("<< figure_number<< ");";

    // Hold on
    if(hold_on)
        sstream<< " hold on;";
    else
        sstream<< " hold off";
    sstream<< std::endl;

    // Plot with options
    if(options != "")
        sstream<< "plot(DATA"<< data_number<< "(:, 1), DATA"<< data_number<< "(:, 2), '"<< options<< "');"<< std::endl;
    else
        sstream<< "plot(DATA"<< data_number<<  "(:, 1), DATA"<< data_number<< "(:, 2));"<< std::endl;
    if(legends != "")
         sstream<< "legend("<< legends<< ");"<<std::endl;
    // Title
    if(title != "")
        sstream<< "title('"<< title<< "');"<< std::endl;

    return sstream.str();
}
