clc; clear all; close all;


DATA1 = importdata('DATA1.txt', '\t');

figure(1); hold off
plot(DATA1(:, 1), DATA1(:, 2));
title('default_title n�1');

DATA2 = importdata('DATA2.txt', '\t');

figure(1); hold on;
plot(DATA2(:, 1), DATA2(:, 2));
title('default_title n�1');

DATA3 = importdata('DATA3.txt', '\t');

figure(1); hold on;
plot(DATA3(:, 1), DATA3(:, 2));
title('default_title n�1');

DATA4 = importdata('DATA4.txt', '\t');

figure(1); hold on;
plot(DATA4(:, 1), DATA4(:, 2));
legend('set', 'multiset', 'map', 'unordered map');
title('comparaison equal');
